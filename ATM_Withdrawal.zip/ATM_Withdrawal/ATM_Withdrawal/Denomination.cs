﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_Withdrawal
{
    public abstract class Denomination
    {
        public abstract int TotalATMMoney { get; set; }
        public abstract int DenominationValue { get; set; }
        public abstract int DenominationTotal { get; set; }
        public abstract int NoteCount { get; set; }

        public abstract int LastWithdrawalCount { get; set; }

        public abstract void WithDrawal(int amount);

        public abstract void LoadMoney(int noteCount);


        protected Denomination successor;

        public void SetSuccessor(Denomination successor)
        {
            this.successor = successor;
        }        
    }

    public class TwoThousand : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 2000;
            }
            set { }
            
        }
       
        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }
        
        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount/ DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;                    
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Thousand : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 1000;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class FiveHundred : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 500;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Hundred : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 100;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Fifty : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 50;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Twenty : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 20;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Ten : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 10;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Five : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 5;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class Two : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 2;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (dCount == 0)
            {
                successor.WithDrawal(amount);
            }
            else
            {
                if (amount > 0 && NoteCount > 0 && NoteCount >= dCount)
                {
                    NoteCount -= dCount;
                    LastWithdrawalCount = dCount;
                    amount -= dCount * DenominationValue;
                }
                else
                {
                    LastWithdrawalCount = NoteCount;
                    amount -= NoteCount * DenominationValue;
                    NoteCount -= NoteCount;
                }
                successor.WithDrawal(amount);
            }

        }
    }

    public class One : Denomination
    {
        public override int DenominationValue
        {
            get
            {
                return 1;
            }
            set { }

        }

        public override int NoteCount
        {
            get; set;
        }

        public override int LastWithdrawalCount
        {
            get; set;
        }

        public override int DenominationTotal
        {
            get; set;
        }

        public override int TotalATMMoney
        {
            get; set;
        }

        public override void LoadMoney(int noteCount)
        {
            NoteCount = noteCount;
            DenominationTotal = noteCount * DenominationValue;
            TotalATMMoney += DenominationTotal;
        }

        public override void WithDrawal(int amount)
        {
            //Get denomination count
            int dCount = amount / DenominationValue;

            //reset last withdrawal count
            LastWithdrawalCount = 0;

            if (amount > 0 && NoteCount > 0 && dCount >0 && NoteCount >= dCount)
            {
                NoteCount -= dCount;
                LastWithdrawalCount = dCount;
                amount -= dCount * DenominationValue;
            }
            else
            {

            }

        }
    }
}
