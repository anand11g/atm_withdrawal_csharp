﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_Withdrawal
{
    class Program
    {
        static void Main(string[] args)
        {
            //Denomination[] group = new Denomination[10];
            int amountWithdraw = 0;

            //Total ATM Money
            int totalATMmoney = 0;

            //display formatted string
            string display;

            //Set chain of resp-
            Denomination twoThousand = new TwoThousand();
            Denomination oneThousand = new Thousand();
            Denomination fiveHundred = new FiveHundred();
            Denomination hundred = new Hundred();
            Denomination fifty = new Fifty();
            Denomination twenty = new Twenty();
            Denomination ten = new Ten();
            Denomination five = new Five();
            Denomination two = new Two();
            Denomination one = new One();

            //set successor for chain reaction
            twoThousand.SetSuccessor(oneThousand);
            oneThousand.SetSuccessor(fiveHundred);
            fiveHundred.SetSuccessor(hundred);
            hundred.SetSuccessor(fifty);
            fifty.SetSuccessor(twenty);
            twenty.SetSuccessor(ten);
            ten.SetSuccessor(five);
            five.SetSuccessor(two);
            two.SetSuccessor(one);

            // Create key value pair collection
            Dictionary<string, Denomination> dict = new Dictionary<string, Denomination>();
            dict.Add("2000", twoThousand);
            dict.Add("1000", oneThousand);
            dict.Add("500", fiveHundred);
            dict.Add("100", hundred);
            dict.Add("50", fifty);
            dict.Add("20", twenty);
            dict.Add("10", ten);
            dict.Add("5", five);
            dict.Add("2", two);
            dict.Add("1", one);

            //loading money to ATM
            // assumption: Each denomination have 20 in count
            foreach (KeyValuePair<string, Denomination> obj in dict)
            {
                obj.Value.LoadMoney(20); //loading 20 notes of each
            }

            //validate the amount can able to withdraw from ATM
            foreach (KeyValuePair<string, Denomination> obj in dict)
            {
                totalATMmoney += obj.Value.DenominationTotal;
            }

            Console.WriteLine("---------Welcome to ABC Bank ATM---------");
            do
            {

                //Prompt the user to enter the money
                Console.WriteLine("Enter your amount to withdraw: ");
                amountWithdraw = Convert.ToInt16(Console.ReadLine());

                if (totalATMmoney >= amountWithdraw)
                {


                    //Withdraw money using - chain of responsibility pattern
                    twoThousand.WithDrawal(amountWithdraw);
                     
                    //update withdrawal
                    totalATMmoney -= amountWithdraw;

                    //Display table
                    int total = 0;
                    int noteCount = 0;
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("    Currency    Count      Amount      ");
                    Console.WriteLine("--------------------------------------------");
                    foreach (KeyValuePair<string, Denomination> obj in dict)
                    {
                        if (obj.Value.LastWithdrawalCount == 0) continue;
                        Console.WriteLine("    {0}          {1}         {2}      ",
                            obj.Value.DenominationValue.ToString().PadLeft(4), obj.Value.LastWithdrawalCount, (obj.Value.DenominationValue * obj.Value.LastWithdrawalCount).ToString().PadLeft(4));

                        total += obj.Value.DenominationValue * obj.Value.LastWithdrawalCount;
                        noteCount += obj.Value.LastWithdrawalCount;
                    }
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("    Total         {0}         {1}", noteCount, total.ToString().PadLeft(4));
                    Console.WriteLine("--------------------------------------------");

                }

                else
                {
                    display = (totalATMmoney == 0) ? "!!!! Opps ATM is out of money..": "---Please enter minimal figure---";
                    Console.WriteLine(display);
                }

                Console.WriteLine("Press Y to continue your withdrawals..");

            }while (Console.ReadKey(true).Key == ConsoleKey.Y);
        }
    }
}
